//>>built
define("dijit/nls/nb/loading",({loadingState:"Laster inn...",errorState:"Det oppsto en feil"}));
